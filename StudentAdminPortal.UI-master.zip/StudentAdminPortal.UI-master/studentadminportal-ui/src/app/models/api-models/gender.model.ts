export interface Gender {
  id: string,
  description: string
}
